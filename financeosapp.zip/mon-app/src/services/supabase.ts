import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  'https://jaedkphnudsrmlrzpflb.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImphZWRrcGhudWRzcm1scnpwZmxiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA2NTg0MTksImV4cCI6MjA5NjIzNDQxOX0.GSaZqkxYzltVwQ48isMX4Kra-lyKma9YoUwxA1803oA'
);
