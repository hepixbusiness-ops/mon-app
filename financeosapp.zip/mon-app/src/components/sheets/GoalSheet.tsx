import React, { forwardRef, useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, ScrollView } from 'react-native';
import { BottomSheetModal, BottomSheetScrollView } from '@gorhom/bottom-sheet';
import { useTheme } from '../../contexts/ThemeContext';
import { useFinanceStore } from '../../store/useFinanceStore';
import { SPACING, RADIUS } from '../../constants/theme';
import { Goal } from '../../types';

const GOAL_ICONS = ['🎯', '📚', '🎄', '🏪', '🚗', '✈️', '🏠', '💊', '🎉', '🎸', '🏋️', '💍', '🌍', '🐕', '👶'];

interface Props {
  goal?: Goal;
  onClose: () => void;
}

const GoalSheet = forwardRef<BottomSheetModal, Props>(({ goal, onClose }, ref) => {
  const theme = useTheme();
  const { addGoal, updateGoal, deleteGoal } = useFinanceStore();

  const [name, setName] = useState('');
  const [icon, setIcon] = useState('🎯');
  const [target, setTarget] = useState('');
  const [monthly, setMonthly] = useState('');
  const [addAmount, setAddAmount] = useState('');

  useEffect(() => {
    if (goal) {
      setName(goal.name);
      setIcon(goal.icon);
      setTarget(String(goal.targetAmount));
      setMonthly(String(goal.monthlyAmount));
    } else {
      setName('');
      setIcon('🎯');
      setTarget('');
      setMonthly('');
    }
    setAddAmount('');
  }, [goal]);

  function handleSave() {
    if (!name.trim() || !target) return;
    if (goal) {
      updateGoal({
        ...goal,
        name: name.trim(),
        icon,
        targetAmount: parseFloat(target) || goal.targetAmount,
        monthlyAmount: parseFloat(monthly) || goal.monthlyAmount,
      });
    } else {
      addGoal({
        name: name.trim(),
        icon,
        targetAmount: parseFloat(target) || 0,
        savedAmount: 0,
        monthlyAmount: parseFloat(monthly) || 0,
        status: 'active',
      });
    }
    (ref as any)?.current?.dismiss();
    onClose();
  }

  function handleAddMoney() {
    if (!goal || !addAmount) return;
    const amt = parseFloat(addAmount) || 0;
    updateGoal({ ...goal, savedAmount: goal.savedAmount + amt });
    setAddAmount('');
    (ref as any)?.current?.dismiss();
  }

  function handleDelete() {
    if (!goal) return;
    deleteGoal(goal.id);
    (ref as any)?.current?.dismiss();
    onClose();
  }

  return (
    <BottomSheetModal
      ref={ref}
      snapPoints={['75%']}
      backgroundStyle={{ backgroundColor: theme.card }}
      handleIndicatorStyle={{ backgroundColor: theme.border.default }}
    >
      <BottomSheetScrollView contentContainerStyle={[styles.container, { paddingHorizontal: SPACING.screen }]}>
        <Text style={[styles.title, { color: theme.text.primary }]}>
          {goal ? 'Modifier l\'objectif' : 'Nouvel objectif'}
        </Text>

        {/* Icon picker */}
        <Text style={[styles.label, { color: theme.text.secondary }]}>Icône</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={styles.iconRow}>
            {GOAL_ICONS.map(i => (
              <TouchableOpacity
                key={i}
                onPress={() => setIcon(i)}
                style={[styles.iconBtn, { backgroundColor: icon === i ? theme.accent + '22' : theme.overlay, borderColor: icon === i ? theme.accent : 'transparent' }]}
              >
                <Text style={{ fontSize: 24 }}>{i}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        <Text style={[styles.label, { color: theme.text.secondary }]}>Nom de l'objectif</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Ex: Rentrée scolaire"
          placeholderTextColor={theme.text.muted}
          style={[styles.input, { backgroundColor: theme.overlay, color: theme.text.primary, borderColor: theme.border.subtle }]}
        />

        <Text style={[styles.label, { color: theme.text.secondary }]}>Montant cible (FCFA)</Text>
        <TextInput
          value={target}
          onChangeText={setTarget}
          keyboardType="numeric"
          placeholder="200 000"
          placeholderTextColor={theme.text.muted}
          style={[styles.input, { backgroundColor: theme.overlay, color: theme.text.primary, borderColor: theme.border.subtle }]}
        />

        <Text style={[styles.label, { color: theme.text.secondary }]}>Épargne mensuelle (FCFA)</Text>
        <TextInput
          value={monthly}
          onChangeText={setMonthly}
          keyboardType="numeric"
          placeholder="20 000"
          placeholderTextColor={theme.text.muted}
          style={[styles.input, { backgroundColor: theme.overlay, color: theme.text.primary, borderColor: theme.border.subtle }]}
        />

        {/* Add money section for existing goals */}
        {goal && (
          <View style={[styles.addMoneySection, { backgroundColor: theme.overlay, borderColor: theme.border.subtle }]}>
            <Text style={[styles.label, { color: theme.text.secondary }]}>Ajouter de l'argent</Text>
            <View style={styles.addMoneyRow}>
              <TextInput
                value={addAmount}
                onChangeText={setAddAmount}
                keyboardType="numeric"
                placeholder="Montant à ajouter"
                placeholderTextColor={theme.text.muted}
                style={[styles.addInput, { backgroundColor: theme.card, color: theme.text.primary, borderColor: theme.border.subtle }]}
              />
              <TouchableOpacity onPress={handleAddMoney} style={[styles.addBtn, { backgroundColor: theme.accent }]}>
                <Text style={styles.addBtnText}>+ Ajouter</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={styles.actions}>
          <TouchableOpacity onPress={handleSave} style={[styles.saveBtn, { backgroundColor: theme.accent }]}>
            <Text style={styles.saveBtnText}>{goal ? 'Enregistrer' : 'Créer'}</Text>
          </TouchableOpacity>
          {goal && (
            <TouchableOpacity onPress={handleDelete} style={[styles.deleteBtn, { borderColor: '#f87171' }]}>
              <Text style={{ color: '#f87171', fontFamily: 'PlusJakartaSans_700Bold', fontSize: 14 }}>Supprimer</Text>
            </TouchableOpacity>
          )}
        </View>
      </BottomSheetScrollView>
    </BottomSheetModal>
  );
});

export default GoalSheet;

const styles = StyleSheet.create({
  container: {
    gap: SPACING.md,
    paddingBottom: SPACING.xxl,
  },
  title: {
    fontSize: 18,
    fontFamily: 'PlusJakartaSans_700Bold',
    textAlign: 'center',
  },
  label: {
    fontSize: 12,
    fontFamily: 'PlusJakartaSans_700Bold',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  iconRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  iconBtn: {
    width: 48,
    height: 48,
    borderRadius: RADIUS.sm,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
  },
  input: {
    height: 52,
    borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.lg,
    fontSize: 15,
    fontFamily: 'PlusJakartaSans_400Regular',
    borderWidth: 1,
  },
  addMoneySection: {
    padding: SPACING.md,
    borderRadius: RADIUS.md,
    borderWidth: 1,
    gap: SPACING.sm,
  },
  addMoneyRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  addInput: {
    flex: 1,
    height: 44,
    borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.md,
    fontSize: 14,
    fontFamily: 'PlusJakartaSans_400Regular',
    borderWidth: 1,
  },
  addBtn: {
    paddingHorizontal: SPACING.lg,
    height: 44,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBtnText: {
    color: '#fff',
    fontSize: 13,
    fontFamily: 'PlusJakartaSans_700Bold',
  },
  actions: {
    gap: SPACING.sm,
    marginTop: SPACING.sm,
  },
  saveBtn: {
    height: 52,
    borderRadius: RADIUS.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveBtnText: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'PlusJakartaSans_700Bold',
  },
  deleteBtn: {
    height: 44,
    borderRadius: RADIUS.md,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
