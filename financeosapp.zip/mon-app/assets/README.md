# Assets

The following image assets are needed:
- icon.png (1024x1024)
- splash.png (1284x2778)
- adaptive-icon.png (1024x1024)

These must be added before building the app.
